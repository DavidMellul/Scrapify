from distutils.core import setup

setup(
    name='scrapify',
    packages=['scrapify'],
    version='3.0',
    description='A  library that allows dead easy web scraping with 3 lines of code.',
    author='David Mellul',
    author_email='david.mellul@outlook.fr',
    url='https://github.com/DavidMellul/Scrapify/scrapify',
    download_url='https://github.com/davidmellul/scrapify/scrapify/archive/1.0.tar.gz',
    install_requires=[
        'unidecode', 'requests', 'lxml'
    ],
    keywords=['networking', 'web', 'scraping', 'data', 'retrieval']
)
